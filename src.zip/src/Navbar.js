import { Link } from 'react-router-dom';

function navbar() {
    return (
        <nav className="Navbar">
            <h1> Augustine</h1>
            <div className="links">
                    <Link to="/">Home</Link>
                    <Link to="/create" style={{ color: "white",
                    backgroundColor:'#333', borderRadius:'23px'

                    }}>New blog</Link>
</div>
        </nav>
    );
}
 
export default navbar;