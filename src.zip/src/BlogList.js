import { Link } from "react-router-dom";

const BlogList=({blogs,title,})=> {
        
    
    return (
        <div className="log-list">
<h1>{title}</h1>
            {blogs.map((blogs) => (
                <div className="blog-preview" key={blogs.id}>
                    <Link to={`/blogs/${blogs.id}`}>
                    <h1>{blogs.title}</h1>
                    <p>written by{blogs.author}</p>
                    </Link>
                    

                </div>
            ))}
        </div>
    );
}

export default BlogList ;